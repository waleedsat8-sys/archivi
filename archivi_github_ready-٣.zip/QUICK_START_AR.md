# أسرع طريقة للحصول على APK (بدون كمبيوتر)

## الخطوة 1: ارفع هذا المجلد إلى GitHub (Repo Public)
- ارفع كل الملفات كما هي.

## الخطوة 2: شغّل البناء
GitHub → Repo → Actions → **APK مباشر** → Run workflow

## الخطوة 3: حمّل الرابط المباشر
Repo → Releases → **Archivi Debug APK** → حمّل `app-debug.apk`

الرابط المباشر سيكون:
`https://github.com/<USER>/<REPO>/releases/download/debug-apk/app-debug.apk`
