This repo is prepared for GitHub Actions build.
